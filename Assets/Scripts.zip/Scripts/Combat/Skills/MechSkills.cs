using System;
using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(MechStats))]
public class MechSkills : MonoBehaviour
{
    [Serializable]
    public class Slot
    {
        public SkillData skill;
        public InputActionReference input;
        [HideInInspector] public float remaining;   // คูลดาวน์ที่เหลือ (หน่วยวินาทีของคูลดาวน์ฐาน)
    }

    [SerializeField] Slot[] slots = new Slot[4];
    [SerializeField] bool debugGui = true;
    [SerializeField] Vector2 debugGuiPos = new Vector2(20f, 80f);

    public MechStats Mech { get; private set; }
    public MechAim Aim { get; private set; }
    StatusController status;
    public bool IsBlocked => !CanCast || (status != null && !status.CanCastSkills);
    public bool CanCast { get; set; } = true;   // ไว้ให้สถานะ (Stun/Silence) ปิดการใช้สกิล

    public event Action<int> SkillCast;         // ส่งเลขช่องที่ใช้

    void Awake()
    {
        Mech = GetComponent<MechStats>();
        status = GetComponent<StatusController>();
        Aim = GetComponent<MechAim>();
    }

    void OnEnable()
    {
        foreach (Slot s in slots)
            if (s != null && s.input != null) s.input.action.Enable();
    }

    void Update()
    {
        float rate = Mathf.Max(0.01f, Mech.Stats.Get(StatId.CooldownRate));

        // ลดคูลดาวน์ตามอัตราปัจจุบัน (อัลติ CooldownRate x10 จึงเร่งของที่กำลังนับอยู่ด้วย)
        foreach (Slot s in slots)
            if (s != null && s.remaining > 0f)
                s.remaining = Mathf.Max(0f, s.remaining - Time.deltaTime * rate);

        if (IsBlocked) return;

        for (int i = 0; i < slots.Length; i++)
        {
            Slot s = slots[i];
            if (s == null || s.skill == null || s.input == null) continue;
            if (s.input.action.WasPressedThisFrame() && s.remaining <= 0f) Cast(i);
        }
    }

    void Cast(int index)
    {
        Slot s = slots[index];
        s.remaining = s.skill.cooldown;   // คูลดาวน์เริ่มนับตอนกดใช้
        s.skill.Activate(this);
        SkillCast?.Invoke(index);
    }

    // วินาทีจริงที่ต้องรอ (คิดตามอัตราปัจจุบัน)
    public float CooldownRemaining(int index) =>
        slots[index].remaining / Mathf.Max(0.01f, Mech.Stats.Get(StatId.CooldownRate));

    // 0-1 สำหรับวงหมุนบน HUD
    public float CooldownRatio(int index) =>
        slots[index].skill != null && slots[index].skill.cooldown > 0f
            ? slots[index].remaining / slots[index].skill.cooldown
            : 0f;

    void OnGUI()
    {
        if (!debugGui) return;
        for (int i = 0; i < slots.Length; i++)
        {
            Slot s = slots[i];
            if (s == null || s.skill == null || s.input == null) continue;
            float rem = CooldownRemaining(i);
            string state = rem > 0f ? rem.ToString("F1") + "s" : "READY";
            GUI.Label(new Rect(debugGuiPos.x, debugGuiPos.y + i * 22f, 400f, 24f),
                s.input.action.name + "  " + s.skill.displayName + "  " + state);
        }
    }
}
using UnityEngine;

public abstract class SkillData : ScriptableObject
{
    [Header("Info")]
    public string id;
    public string displayName;
    public Sprite icon;          // ไว้ใช้กับ HUD ทีหลัง

    [Header("Cooldown")]
    public float cooldown = 5f;

    public abstract void Activate(MechSkills user);
}
using System;
using UnityEngine;
using UnityEngine.InputSystem;

public class UltimateGauge : MonoBehaviour
{
    [Header("Gauge")]
    [SerializeField] float max = 100f;
    [SerializeField] float passiveRate = 1f;         // เติมเองต่อวินาที
    [SerializeField] float defaultKillCharge = 1f;   // ใช้เมื่อเป้าที่ตายไม่มี Tier

    [Header("Ultimate")]
    [SerializeField] InputActionReference input;     // Skill3 (R)
    [SerializeField] StatusData ultimateStatus;
    [SerializeField] float duration = 10f;

    [Header("Debug")]
    [SerializeField] bool debugGui = true;
    [SerializeField] Vector2 debugGuiPos = new Vector2(20f, 170f);

    StatusController status;
    float activeEnd;

    public float Current { get; private set; }
    public float Max => max;
    public float Ratio => max > 0f ? Current / max : 0f;
    public bool IsFull => Current >= max;
    public bool IsActive => Time.time < activeEnd;
    public float ActiveRemaining => Mathf.Max(0f, activeEnd - Time.time);

    public event Action<float, float> Changed;   // current, max
    public event Action Activated;

    void Awake() => status = GetComponent<StatusController>();

    void OnEnable()
    {
        input.action.Enable();
        Health.AnyDied += OnAnyDied;
    }

    void OnDisable() => Health.AnyDied -= OnAnyDied;

    void Update()
    {
        AddCharge(passiveRate * Time.deltaTime);

        bool canCast = status == null || status.CanCastSkills;
        if (canCast && IsFull && !IsActive && input.action.WasPressedThisFrame())
            Activate();
    }

    // ไม่เติมระหว่างอัลติทำงาน
    public void AddCharge(float amount)
    {
        if (amount <= 0f || IsActive) return;

        float before = Current;
        Current = Mathf.Min(max, Current + amount);
        if (Current != before) Changed?.Invoke(Current, max);
    }

    void Activate()
    {
        Current = 0f;
        activeEnd = Time.time + duration;
        if (status != null) status.Apply(ultimateStatus, gameObject, duration);
        Changed?.Invoke(Current, max);
        Activated?.Invoke();
    }

    // นับเฉพาะที่ผู้เล่นเป็นคนฆ่า (ระเบิด missile ก็ส่ง source เป็นผู้เล่น)
    void OnAnyDied(Health victim, DamageResult r)
    {
        if (r.source != gameObject) return;

        StatusController sc = victim.GetComponent<StatusController>();
        TierData tier = sc != null ? sc.Tier : null;
        AddCharge(tier != null ? tier.ultChargeOnKill : defaultKillCharge);
    }

    void OnGUI()
    {
        if (!debugGui) return;

        string s = IsActive
            ? "ULT ACTIVE  " + ActiveRemaining.ToString("F1") + "s"
            : IsFull ? "ULT READY  (R)" : "ULT  " + Mathf.FloorToInt(Ratio * 100f) + "%";
        GUI.Label(new Rect(debugGuiPos.x, debugGuiPos.y, 400f, 24f), s);
    }
}